﻿namespace Summer.App.Contracts.IServices
{
    public interface IBaseService
    {
        
    }
}