﻿namespace Summer.App.Contracts.Base.Consts
{
    public static class AppClaimTypes
    {
        public const string Id = "u_id";

        public const string Account = "u_account";
    }
}