﻿namespace Summer.App.Contracts.Base.IServices
{
    public interface IBaseService
    {
        
    }
}