﻿
namespace Summer.App.Contracts.Base.Dtos
{
    public class TokenDto
    {
        public string Token { get; set; }
    }
}
