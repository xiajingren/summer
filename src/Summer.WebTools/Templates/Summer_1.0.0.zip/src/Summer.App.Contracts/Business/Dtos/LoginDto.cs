﻿namespace Summer.App.Contracts.Business.Dtos
{
    public class LoginDto
    {
        public string Account { get; set; }

        public string Password { get; set; }
    }
}