﻿namespace Summer.WebTools.Tools.Generator
{
    public class EntryModel
    {
        public string Name { get; set; }

        public bool IsFile { get; set; }

        public string Content { get; set; }

        public bool IsRemove { get; set; }
    }
}