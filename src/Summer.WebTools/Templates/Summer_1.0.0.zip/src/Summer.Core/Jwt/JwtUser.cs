﻿using System;

namespace Summer.Core.Jwt
{
    public class JwtUser
    {
        public Guid Id { get; set; }
    }
}