﻿
namespace Summer.Core.Jwt
{
    public class JwtToken
    {
        public string Token { get; set; }
    }
}
